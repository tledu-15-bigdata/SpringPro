package com.tledu.cn.proxy.static_proxy;

public interface Movie {
     void play();
 }