package com.tledu.cn.actual.dao;

public interface HisDao {

    public int work(int a,int b);
}
