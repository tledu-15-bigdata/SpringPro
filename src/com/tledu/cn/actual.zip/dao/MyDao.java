package com.tledu.cn.actual.dao;

import org.springframework.stereotype.Repository;

//@Repository
public class MyDao {
    public int work(int a,int b){

        return a+b;
    }
}
