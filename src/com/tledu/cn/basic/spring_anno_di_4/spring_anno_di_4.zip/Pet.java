package com.tledu.cn.basic.spring_anno_di_4;

public interface Pet {
    String fetchName();
}
