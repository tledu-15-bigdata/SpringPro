package com.tledu.cn.basic.spring_jdbc_5.anno;

import com.tledu.cn.actual.service.MyService;
import com.tledu.cn.basic.spring_jdbc_5.anno.dao.SpringDao;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringJDBCRun {

    ApplicationContext applicationContext=null;

    @Test
    public void constructorDI(){
//        myService
        SpringDao tea= (SpringDao) applicationContext.getBean("springDao");
//        int work = tea.work(1, 3);

        System.out.println(tea.queryAll());
    }


    @Before
    public void loadEnv(){
        applicationContext=new AnnotationConfigApplicationContext(SpringConfig.class);
    }

}
