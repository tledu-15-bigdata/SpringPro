package com.tledu.cn.basic.spring_jdbc_5.anno.dao;

import com.tledu.cn.basic.spring_jdbc_5.anno.pojo.Dept;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@Repository
public class SpringDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;



    public List<Dept> queryAll() throws SQLException {
        Connection conn=jdbcTemplate.getDataSource().getConnection();
        conn.setAutoCommit(false);
        List<Dept> deptList=jdbcTemplate.query("select * from dept", new BeanPropertyRowMapper<Dept>(Dept.class));
        conn.commit();
        conn.rollback();
        return deptList;
    }


}
